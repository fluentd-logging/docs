package com.rudra.aks.fluentd.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class DemoRestController {

	private static Logger logger = LoggerFactory.getLogger(DemoRestController.class);
	
	@RequestMapping("/")
	public String testRest() {
		logger.info("Start : " + getClass().getName() + " : testRest()");
		return "hello fluentd";
	}
}

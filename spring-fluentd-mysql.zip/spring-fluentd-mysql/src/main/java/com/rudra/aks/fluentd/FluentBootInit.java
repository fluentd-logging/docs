package com.rudra.aks.fluentd;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FluentBootInit {

	public static void main(String args[]) {
		SpringApplication.run(FluentBootInit.class, args);
	}
}
